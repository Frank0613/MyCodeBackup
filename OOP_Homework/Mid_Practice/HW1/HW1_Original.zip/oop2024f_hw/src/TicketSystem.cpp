#include "TicketSystem.hpp"

int CheckTicketPrice(Order ticket){

    switch () {

    }

}
int CheckTodaySales(std::vector<Order> tickets){

}
int CheckTodayTicketSales(std::vector<Order> tickets){

}
int CheckSpecificTicketSales(TicketType type,std::vector<Order> tickets){

}
int CheckSpecificOrdersTicketPrice(int idx,std::vector<Order> tickets){

}
